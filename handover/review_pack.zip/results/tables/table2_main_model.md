| Architecture   | Features   |   Parameters |   Dev EER (%) |   Eval EER (%) |   Eval ROC-AUC |   Eval min-tDCF |
|:---------------|:-----------|-------------:|--------------:|---------------:|---------------:|----------------:|
| CRNN-LFCC      | LFCC       |    1,439,778 |          1.15 |           6.7  |         0.98   |          0.2143 |
| CRNN-LOGMEL    | LOGMEL     |    1,472,546 |          2.37 |          10.28 |         0.9554 |          0.2691 |