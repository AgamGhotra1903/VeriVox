# Index of Result & Metric Artifacts

This index enumerates all serialized metrics files currently in the repository, their verified data source (`REAL` vs `SMOKE`), seed, evaluated model/subsystem, key metrics exactly as stored, and generation timestamp.

## 1. Verified Genuine Evaluation Metrics (`results/metrics/`)

| Result File Path | Data Source | Seed | Model / Subsystem | Key Metrics Exactly as Stored | Timestamp |
| :--- | :---: | :---: | :--- | :--- | :--- |
| `results/metrics/api_load_test.json` | **REAL** | 42 | FastAPI Service Concurrency | c=1: 1263.4 RPS, p50 0.73ms; c=20: 1527.0 RPS, p50 11.16ms (100% success) | `2026-11-05T18:09:04.227446+00:00` |
| `results/metrics/audits.json` | **REAL** | 42 | Forensic Audits | Silence Classifier EER: 22.78%, AUC: 0.8509; VAD Untrimmed: 7.91% -> Trimmed: 39.13% (Delta: +31.22 pts) | `2026-11-05T09:08:32.030934+00:00` |
| `results/metrics/band_analysis_results.json` | **REAL** | 42 | CRNN-LFCC Occlusion Ablation | Baseline: 2.90%; 4-6kHz: 6.32% (+3.42 pts); <4kHz Low-pass: 11.63% (+8.73 pts) | `2026-11-05T07:44:32.258506+00:00` |
| `results/metrics/baselines_results.json` | **REAL** | 42 | Classical 8-Model Sweep | Models: GMM, LR, SVM, RF (LFCC & Log-Mel). Best: GMM-LFCC Eval EER 11.46% | `2026-11-05T06:49:17.794497+00:00` |
| `results/metrics/classical_sweep.json` | **REAL** | 42 | Classical Sweep Details | SVM-LFCC Eval EER: 19.64%; RF-LFCC Eval EER: 17.52% | `2026-11-05T06:49:17.794497+00:00` |
| `results/metrics/codec_robustness_results.json` | **REAL** | 42 | Codec Robustness (MP3, AAC, Opus) | MP3 16k: CRNN 74.81% / Ens 53.92%; AAC 16k: CRNN 75.35% / Ens 28.67% | `2026-11-05T17:18:38.386888+00:00` |
| `results/metrics/crnn_lfcc_results.json` | **REAL** | 42 | CRNN-LFCC | Dev EER: 2.90%, min-tDCF: 0.1416; Eval EER: 8.39%, min-tDCF: 0.2624, AUC: 0.9707 | `2026-11-05T07:37:34.521053+00:00` |
| `results/metrics/crnn_logmel_results.json` | **REAL** | 42 | CRNN-LogMel | Dev EER: 50.00%; Eval EER: 50.00%, min-tDCF: 1.0000, AUC: 0.5000 (Complete Failure) | `2026-11-05T08:06:38.941348+00:00` |
| `results/metrics/crnn_results.json` | **REAL** | 42 | CRNN-LFCC | Dev EER: 2.90%, min-tDCF: 0.1416; Eval EER: 8.39%, min-tDCF: 0.2624, AUC: 0.9707 | `2026-11-05T07:37:34.521053+00:00` |
| `results/metrics/degradation_chains_results.json` | **REAL** | 42 | Acoustic Degradation Chains | ALAW: CRNN 69.29% / Ens 31.14%; SNR 10dB: CRNN 28.00% / Ens 69.86% | `2026-11-05T17:35:45.282618+00:00` |
| `results/metrics/ensemble_results.json` | **REAL** | 42 | Stacked Ensemble (L2 Logistic Regression) | Dev EER: 3.75%; Eval EER: 12.55%, min-tDCF: 0.3192, AUC: 0.9474, Recall: 98.15% | `2026-11-05T08:16:23.541976+00:00` |
| `results/metrics/error_audit.json` | **REAL** | 42 | Error Audit | Total trials: 71237; FP: 8414, FN: 267, Vulnerable: A18 (27.57%) | `2026-11-05T09:08:32.030934+00:00` |
| `results/metrics/gmm_baseline.json` | **REAL** | 42 | LFCC-GMM (512 comp) | Dev EER: 8.07%; Eval EER: 11.46%, min-tDCF: 0.3572, AUC: 0.9544 | `2026-11-05T06:30:47.420628+00:00` |
| `results/metrics/in_the_wild_results.json` | **REAL** | 42 | In-the-Wild Cross-Domain (Müller et al., N=25,587) | CRNN (mean) EER: 74.77%, AUC: 0.1703; Ensemble EER: 84.15%, AUC: 0.0869 (Inversion) | `2026-11-05T11:37:28.090955+00:00` |
| `results/metrics/latency.json` | **REAL** | 42 | Latency Benchmark | CPU 1-thread: 12.74 ms (RTF: 0.00318); MPS: 32.21 ms (RTF: 0.00805) | `2026-11-05T18:06:01.758118+00:00` |
| `results/metrics/logo_crossval.json` | **REAL** | 42 | Leave-One-Generator-Out (LOGO) | Mean LOGO EER: 28.49%; Folds: A01: 4.79%, A04: 42.55%, A06: 57.50% | `2026-11-05T09:08:32.030934+00:00` |
| `results/metrics/per_attack_evaluation.json` | **REAL** | 42 | A07-A19 Attack Evaluation | Worst attack A18: CRNN EER 27.57%, min-tDCF 0.8470; Ens EER 39.14%, min-tDCF 0.9996 | `2026-11-05T09:08:32.030934+00:00` |
| `results/metrics/quantization_benchmark.json` | **REAL** | 42 | Model Export & Quantization | FP32: 16.6MB, 11.04ms; ONNX: 5.5MB (3.0x), 2.80ms (RTF 0.0007); INT8: 5.2MB | `2026-11-05T18:06:43.707632+00:00` |
| `results/metrics/speaker_bootstrap.json` | **REAL** | 42 | Speaker Bootstrap (B=1,000 across 67 speakers) | CRNN EER: 8.39% [7.43, 9.71], min-tDCF: 0.2624; Ens EER: 14.75% [13.43, 16.16] | `2026-11-05T09:08:32.030934+00:00` |
| `results/metrics/stage5_audits_results.json` | **REAL** | 42 | Forensic Audits | Silence Classifier EER: 0.00%, AUC: 0.0000; VAD Untrimmed: 0.00% -> Trimmed: 0.00% (Delta: +0.00 pts) | `2026-11-05T09:08:32.030934+00:00` |

## 2. Legacy Mock Smoke-Test Metrics (`results_smoke/metrics/`)

> [!NOTE]
> These records represent the retracted synthetic smoke-test sanity checks from Phase 0 (`data/smoke_test`). They are preserved strictly for audit trail and pipeline verification comparison.

| Result File Path | Data Source | Seed | Model / Subsystem | Key Metrics Exactly as Stored | Timestamp |
| :--- | :---: | :---: | :--- | :--- | :--- |
| `results_smoke/metrics/baselines_results.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/codec_robustness_ensemble.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/crnn_lfcc_results.json` | **SMOKE** | 42 | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/crnn_logmel_results.json` | **SMOKE** | 42 | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/crnn_results.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/crnn_training_run_lfcc_seed42.json` | **SMOKE** | 42 | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/crnn_training_run_logmel_seed42.json` | **SMOKE** | 42 | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/crossdomain_ensemble.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/crossdomain_results.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/error_analysis_summary.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/master_evaluation.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/robustness_results.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
| `results_smoke/metrics/silence_shortcut_analysis.json` | **SMOKE** | N/A | Mock Sanity Fixture | EER: 0.0000%, ROC-AUC: 1.0000, min-tDCF: 0.0000 (Synthetic Sine Tones) | `N/A` |
